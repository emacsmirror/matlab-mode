function bar
    disp('in bar')
end

