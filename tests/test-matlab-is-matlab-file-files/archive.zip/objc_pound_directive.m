#define whatever
